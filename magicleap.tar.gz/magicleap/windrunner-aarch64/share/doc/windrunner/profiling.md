# Using perfetto/PerCetto with Windrunner

<!--
# %BANNER_BEGIN%
# ---------------------------------------------------------------------
# %COPYRIGHT_BEGIN%
#
# Copyright (c) 2021 Magic Leap, Inc. (COMPANY) All Rights Reserved.
# Magic Leap, Inc. Confidential and Proprietary
#
#  NOTICE:  All information contained herein is, and remains the property
#  of COMPANY. The intellectual and technical concepts contained herein
#  are proprietary to COMPANY and may be covered by U.S. and Foreign
#  Patents, patents in process, and are protected by trade secret or
#  copyright law.  Dissemination of this information or reproduction of
#  this material is strictly forbidden unless prior written permission is
#  obtained from COMPANY.  Access to the source code contained herein is
#  hereby forbidden to anyone except current COMPANY employees, managers
#  or contractors who have executed Confidentiality and Non-disclosure
#  agreements explicitly covering such access.
#
#  The copyright notice above does not evidence any actual or intended
#  publication or disclosure  of  this source code, which includes
#  information that is confidential and/or proprietary, and is a trade
#  secret, of  COMPANY.   ANY REPRODUCTION, MODIFICATION, DISTRIBUTION,
#  PUBLIC  PERFORMANCE, OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS
#  SOURCE CODE  WITHOUT THE EXPRESS WRITTEN CONSENT OF COMPANY IS
#  STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS AND
#  INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE
#  CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS
#  TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE,
#  USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
#
# %COPYRIGHT_END%
# ---------------------------------------------------------------------
# %BANNER_END%
#
# SPDX-License-Identifier: LicenseRef-MagicLeap
-->
Monado has integrated perfetto (a profiling tool) via perCetto (a C wrapper
around it providing some useful functionality), and we've incorporated those two
dependencies in to the build as submodules.

This is now automatically a part of the build, if you start a new build after it
was added. Otherwise, you might need to pass `-DXRT_FEATURE_TRACING=ON` to
`cmake` to enable it.

## Tagging functions

Add `#include "util/u_trace_marker.h"` to files to be profiled.

To add a function to be profiled, add

```c++
COMP_TRACE_MARKER();
```

or

```c++
U_TRACE_EVENT(<category>, __func__);
```

at the start of the function, where `<category>` is one of

- vk
- xrt
- sink
- oxr
- comp
- ipc
- timing

See `monado/src/xrt/auxiliary/util/u_trace_marker.h` for more info and macros.

## Perfetto tools

Even though the Perfetto SDK is integrated into the build to include in
Windrunner, there are separately-built tools.

Binaries for Ubuntu 20.04 (Focal) and newer can be found at
<https://gitlab.magicleap.io/windrunner_team/perfetto/-/tags/ml%2Fv23%2F20220127>

If you need to rebuild it yourself for some reason and the CI-built ones above
aren't enough, the following instructions will work:

```sh
cd external/perfetto
tools/install-build-deps   # ML desktops may need "sudo" here?
tools/gn gen --args='is_debug=false' out/linux
tools/ninja -C out/linux tracebox traced traced_probes perfetto
```

## Running

Start perfetto:

```sh
./path_to_perfetto_binaries/traced &
./path_to_perfetto_binaries/traced_probes &
./path_to_perfetto_binaries/perfetto --txt -c perfetto_events.cfg -o windrunner.trace
```

(Note that `perfetto_events.cfg` is a file in this repository that the tool must find.)

`export XRT_TRACING=on`, run Windrunner service, the remote viewer, and your OpenXR app as normal.
When you want to stop profiling, press `ctrl-c` in the terminal perfetto is running in.
The profile data will be in `windrunner.trace`.

To view the data, open this URL: <https://system-observer-sandbox.launchpad.magicleap.black/#!/>
PLEASE DO NOT UPLOAD ANY ML2 trace logs to the Tracer Viewer UI hosted by Google, `httpx://ui.perfetto.dev`

Click "Open trace file" and select the `windrunner.trace` file. Note that only
the base function name is logged, the class/namespace will not be displayed.

- Zoom: ctrl+mousewheel
- Scroll: shift+click+drag
