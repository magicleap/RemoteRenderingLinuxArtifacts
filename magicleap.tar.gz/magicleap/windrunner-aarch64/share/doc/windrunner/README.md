# Windrunner

<!--
SPDX-License-Identifier: CC0-1.0
SPDX-FileCopyrightText: 2020 Collabora, Ltd.
-->

This is a remote-rendering OpenXR implementation built on [Monado](https://monado.freedesktop.org).

When updating this repository, including switching between branches, be sure to run

```shell
git submodule update --recursive --init
```

to ensure your `monado/` directory/submodule on your local
checkout matches the commit you're on.

Pull the LFS files by running:

```shell
git submodule foreach git lfs pull
```

## One-time setup

Note that Windows has separate building instructions in <BUILDING_WINDOWS.md>.

### Build environment dependencies

**NOTE**: If you update this list, please also update `.gitlab-ci/config.yml`
and follow the steps there!

WindRunner requires few packages to be installed. To do so simply run:

```bash
sudo apt-get update &&\
sudo apt-get install -y \
                build-essential \
                clang-format \
                cmake \
                git \
                glslang-tools \
                libavcodec-dev \
                libavformat-dev \
                libavutil-dev \
                libegl-dev \
                libeigen3-dev \
                libgl1-mesa-dev \
                libgles-dev \
                libglfw3-dev \
                libglm-dev \
                libglvnd-dev \
                libgmock-dev \
                libgtest-dev \
                libsdl2-dev \
                libssl-dev \
                libudev-dev \
                libvulkan-dev \
                libx11-dev \
                libx11-xcb-dev \
                libxcb-randr0-dev \
                libxrandr-dev \
                libxxf86vm-dev \
                ninja-build \
                pkg-config \
                python3 \
                python3-pip \
                zlib1g-dev \
                libpulse-dev \
                libopus-dev \
                libssl-dev \
                libbsd-dev \
                libevent-dev \
                golang \
                libsystemd-dev \
                perl

pip3 install --upgrade pip &&\
sudo pip3 install cmakelang
```

NVIDIA drivers and libraries are also needed, and special care has to be taken to install NVIDIA libraries that match exactly the installed display driver.

Assuming that the NVIDIA drivers are installed correctly the following command will add the required libraries:

```bash
NVIDIA_VERSION=$(nvidia-smi --format=csv,noheader --query-gpu="driver_version" | cut -d '.' -f 1) &&\
sudo apt-get install -y \
                "libnvidia-encode-${NVIDIA_VERSION}" \
                "libnvidia-compute-${NVIDIA_VERSION}"
```

For the NVIDIA drivers version 470 or later is required, version 495 or later is recommended.

(The OpenGL ES dev package `libgles-dev` is temporary only, will be removed after an upstream build issue is fixed.)

Alternately, if you have access to Harbor <https://registry.magicleap.io> and
have been added to the `windrunner_team` project there, you can run
`./docker-build-env.sh` to use the same container as the CI. It will mount the
repo in the same path as in your host system, with the same user/group ID. Just
be sure to use a separate build directory if you have both a native/host-distro
build and a Docker build.

### Installing the OpenXR Loader

This isn't strictly a dependency for Windrunner, but it is required for most OpenXR applications.

```sh
# On Ubuntu 20.04 and 18.04 only. Newer distros come with the loader in their default repositories
sudo add-apt-repository ppa:monado-xr/monado
sudo apt update

# On all Ubuntu/Debian distributions
sudo apt install libopenxr-loader1  # lets you run pre-compiled apps
sudo apt install libopenxr-dev      # lets you compile apps that aren't bundled with the OpenXR SDK
sudo apt install libopenxr-utils    # contains hello_xr (which won't run right now due to no depth layers) and a CLI app/tool
```

### Set as a default runtime or override default runtime

Assuming you're in the Windrunner source directory and you will follow the
instructions below to put your build in `build` (change paths as appropriate):

```sh
mkdir -p ~/.config/openxr/1/

# expose as an available runtime for e.g. runtime choosers
ln -s $(pwd)/build/openxr_windrunner-dev.json ~/.config/openxr/1/

# set as active
ln -s ~/.config/openxr/1/openxr_windrunner-dev.json ~/.config/openxr/1/active_runtime.json
```

Instead of this, you may set the `XR_RUNTIME_JSON=<insert_windrunner_path>/build/openxr_windrunner-dev.json` environment variable each time you launch an OpenXR app, to override the `active_runtime.json` setting. This can be done for an entire shell:

```sh
export XR_RUNTIME_JSON=/home/ryan/mgl/windrunner/build/openxr_windrunner-dev.json
some_openxr_app
```

or for a single program launch:

```sh
env XR_RUNTIME_JSON=/home/ryan/mgl/windrunner/build/openxr_windrunner-dev.json some_openxr_app
```

(Those using Bash as their default shell can omit `env` from that command.)

### Teach server IP and port to device (optional)

Use the helper script to tell the device your computer (server's) IP address and port
on the network that they share - 50051 is the default port:

```sh
./SetupRemoteViewerIP
```

## Daily development and usage

### Configure and build

Run all build commands (cmake, ninja) from the root of the mono repo.

Configure the project using CMake (source in `.`, build/binary directory in
`build`) and build with Ninja:

```shell
cmake -G Ninja -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo  # or other configuration options as desired

ninja -C build
```

Once you've configured a directory once, you can just use the `ninja` command to
build. Windrunner is a pretty standard CMake project, so other techniques you
have for working with CMake projects (editor extensions, etc) are all fine to
use here.

Some notable build options:

- `-DXRT_FEATURE_IPC=OFF` disables "service mode" and puts the entire runtime in
  the single .so file. By default, there's a service that needs to be started
  `build/src/windrunner/targets/service/windrunner-service` before executing an
  OpenXR application.
- `-DXRT_FEATURE_TRACING=OFF` disables use of perfetto/PerCetto, which is now
  automatically built and on by default. See <profiling.md> for details on how
  to use Perfetto if you leave it enabled.

## Configure/Building with vcpkg

### Using an exported bundle of dependencies

Get the vcpkg exported bundle from
<https://gitlab.magicleap.io/windrunner_team/vcpkg-builder/-/pipelines> by
clicking on the artifacts button (the three vertical dots) and downloading the
`build-android:archive` artifact, then unpack the downloaded `artifacts.zip` file
and find the `.7z` packed bundle inside it, which would also have to be
unpacked.

Change `your-path/vcpkg-linux-android` to whatever your extracted
vcpkg dependency bundle is called in the following command:

```pwsh
cmake -G Ninja -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo "-DCMAKE_TOOLCHAIN_FILE=your-path/vcpkg-linux-android/scripts/buildsystems/vcpkg.cmake" -DVCPKG_MANIFEST_MODE=OFF -DX_VCPKG_APPLOCAL_DEPS_INSTALL=ON
```

The two main important config variables here are `CMAKE_TOOLCHAIN_FILE` (to
point CMake to our bundle) and `VCPKG_MANIFEST_MODE` to turn off "manifest
mode". (The CMAKE_BUILD_TYPE is standard for any single-configuration generator
invocation of CMake.) We must pass the flag to disable manifest mode here
because an exported bundle does not include the `vcpkg.exe` executable or other
files required to do builds from scratch according to the manifest.

Your `ninja.build` file is in `build\`.

Of course, you may use other methods of generating a CMake build tree as long as the
two defines listed above (`CMAKE_TOOLCHAIN_FILE=...` and
`VCPKG_MANIFEST_MODE=OFF`) are set appropriately.

### Using a full clone of vcpkg

Alternately, you can work with a local full clone of [our vcpkg fork][]. In this
mode, vcpkg has access to its executable, so it will build/copy a build locally
of each dependency listed in the `vcpkg.json` "manifest" file of the source
tree. This is how to work on adding or updating dependencies.

Additional packages maybe required to install before building:
```bash
# Ubuntu focal/20.04.5
sudo apt-get update &&\
sudo apt-get install -y \
    curl \
    git \
    gnupg \
    nasm \
    perl \
    tzdata \
```

Your configure command will look something like this (just replace
`your-path/src/vcpkg` with wherever you cloned our vcpkg fork.)

```pwsh
cmake -G Ninja -S . -B build -DCMAKE_BUILD_TYPE=RelWithDebInfo "-DCMAKE_TOOLCHAIN_FILE=your-path/src/vcpkg/scripts/buildsystems/vcpkg.cmake"
```

**Make sure** to pass `-disableMetrics` when bootstrapping vcpkg, to avoid
leaking file paths.

Also, see the preceding section for an important **note** about choosing a CMake
generator.

### Certificates

Windrunner uses TLS for transmission encryption. Valid certificate has to be provided using environmental variables:
- `LR_TRANSPORT_CERT_PATH` - the path of the host certificate file,
- `LR_TRANSPORT_PKEY_PATH` - the path of the host private key.

If above environmental variables are not provided, service will look for `server.crt` and `server.key` in the **current working directory**.

> **Note**: In `DEBUG` and `RelWithDebInfo` debug certificates are automatically copied to the output directory.

#### Certificates on Windows
On Windows the certificate key-pair will be fetched from the Registry after successful Windrunner installation.
Related registry keys are located in `HKLM:\SOFTWARE\Magic Leap, Inc.\Windrunner`.

### Start both ends of the runtime

If your build is configured in service mode (default), you'll need to first
start the service and leave it running in a terminal:

```sh
cd build/windrunner/src/windrunner/targets/service; ./windrunner-service
```

(To see all debugging environment variables it checks, set the environment
variable `XRT_PRINT_OPTIONS` to 1 or `TRUE` before starting the service.)

You may now launch the viewer app on the device with:

```sh
adb shell am start -S com.magicleap.remote_viewer_app/android.app.NativeActivity
```

You may pass intent extras to remoteviewer for ad-hoc changes to arguments.
```sh
adb shell am start -S -e -h 127.0.0.1:50051 -e -s 0 com.magicleap.remote_viewer_app/android.app.NativeActivity
```
After a valid set of arguments is supplied they are stored as preferences.

You may need to restart the viewer app if the service is restarted.

### Run an OpenXR app

*Important limitation*: Note that only OpenXR apps that submit a depth layer
along with their projection layer will work optimally. You can test with other
apps (like hello_xr), but they will not work as well as those with a depth
layer.

Just as with the service, you can set the environment variable
`XRT_PRINT_OPTIONS` to 1 or `TRUE` before launching an app to see what debugging
environment variables the in-process portion of the runtime is checking.

One such useful environment debug variable, which only works if you installed
`libsdl2-dev` before building, is turning on the debug gui (available in both
the service and the OpenXR loadable runtime .so parts) with `XRT_DEBUG_GUI=1`.

If you didn't set the `active_runtime.json` symlink, see above for information
on setting `XR_RUNTIME_JSON` to override your default OpenXR runtime.

### Test Apps in Use

1. VirtualGround from <https://gitlab.freedesktop.org/wallbraker/apps> You can
   download it, and then run it by first
   `chmod +x VirtualGround-x86_64.AppImage` and then
   `./VirtualGround-x86_64.AppImage ar` You will likely need to install
   libsdl2-dev for this app to work correctly.
   On Windows, download VirtualGround.exe and openxr_loader.dll to the same directory.
2. The Unreal OpenXR template has been packaged and tested, and
[can be downloaded from the Google Drive](https://drive.google.com/drive/folders/1Cff7E7M9SUCJA8FjEaRS2gOUMiD_mD8Y?usp=sharing)

### Vulkan layers

Windrunner uses Vulkan to pack the OpenXR application's output into an image
that is then encoded and sent to the device.
You may enable the validation layers by setting the following environment
variable:
- `VK_INSTANCE_LAYERS=VK_LAYER_KHRONOS_validation`

> **Note**: There is a bug in Vulkan SDK 1.2.131 (provided by default in Ubuntu 20.04 LTS) that causes Windrunner to crash when using `VK_LAYER_KHRONOS_validation`. Follow the instructions at <https://vulkan.lunarg.com/sdk/home> to update your installation of Vulkan SDK.

## Continuous Integration

This is built and tested using primarily an Ubuntu 20.04 image based on one used
by upstream Monado to perform build tests in their CI. To modify it, edit
`.gitlab-ci/config.yml`. **Any time the file is edited in a way that would
affect the generated dockerfile, the `tag` value for each affected image in
`.gitlab-ci/config.yml` must be updated for the changes to take effect!** You
also need to run `make -f .gitlab-ci/ci-scripts.mk` to update the generated
files: see the readme in that directory for details.

The first CI stage checks to see if [Harbor](https://registry.magicleap.io) has
the parent image from upstream as well as the image specified by the `tag`. If
the upstream image is missing, it is copied, so we use those layers directly from
the internal registry, not repeatedly fetching them from Monado. If it does not
contain an image matching `tag`, it will build and push one automatically. (This
is done by `.gitlab-ci/container-prep.sh`)

The actual commands run on the CI to perform the basic build and test are pretty
simple, and can be found in `.gitlab-ci/ci.template`. (They get included in the
`.gitlab-ci.yml` file by a templating process.)

If you are adjusting the CI in some way and want the full pipeline to run
(except for pages publishing), similar to what happens on `main`, name your
branch something starting with `ci-`. This will test the full packaging and
container pipeline, not just the normal merge-request pipeline.

### Formatting
The script scripts/format-project.sh should be run before checking in code changes
for review. This will allow the code to pass formatting checks.

## Versioning

Currently, versions are generated mostly by git (using `git describe` and a
regex in `versioning.cmake`) based on **annotated** tags. They take the format
"MAJOR.MINOR.PATCH.TWEAK.git.HASHFRAGMENT", where everything except `.` and
`.git.` are placeholders. MAJOR, MINOR, and PATCH are from the most recent
annotated tag, made like this:

```sh
git tag -a 0.1.2 -m "Release version 0.1.2"
git push origin 0.1.2
```

TWEAK is the number of commits past that tag, and HASHFRAGMENT is
enough of the git commit hash to uniquely identify the commit. It is included to
disambiguate branches: branches cause several commits to be the distance in
history after a tag.

If a tagged version is being built, the last two version components are omitted.

## Building for arm64/aarch64

The easiest way to build for arm64/aarch64 is to build "natively" within an
arm64 container which is running on x86 with qemu emulation.

Set up qemu for docker with:

```sh
sudo apt-get install qemu binfmt-support qemu-user-static
docker run --rm --privileged multiarch/qemu-user-static --reset -p yes

# Test docker arm64 emulation
docker run --rm -t arm64v8/ubuntu uname -m
# aarch64
```

Then run a container for the distro you wish to build with with arm64 emulation:

```sh
docker run --network host --platform=linux/arm64 --rm -it -v `pwd`:/workspace \
    -w /workspace ubuntu:focal
```

From inside the container, whitelist /workspace as a safe git directory (needed
by the build rules to acquire VERSION information).

```sh
git config --global --add safe.directory /workspace
```

Then follow the build instructions above as normal, including installing all apt
package dependencies.
