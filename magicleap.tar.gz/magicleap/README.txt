IMPORTANT: PLEASE READ THIS NOTICE CAREFULLY BEFORE USING THE MAGIC LEAP 2 DEVELOPER RESOURCES PUBLISHED ON THIS WEBSITE.

Welcome, and thank you for exploring our Magic Leap 2 developer resources. Please note that your use of the ML2 developer resources in this repository is governed by the Magic Leap 2 Software License Agreement, the latest version of which is available at https://www.magicleap.com/software-license-agreement-ml2 (the "ML2 LICENSE AGREEMENT").

By downloading any of the ML2 developer resources, YOU REPRESENT YOU HAVE READ, UNDERSTAND, AND AGREE TO BE BOUND BY THE TERMS AND CONDITIONS OF THE ML2 LICENSE AGREEMENT, and the materials contained this repository are deemed SDK Materials (as defined in the ML2 License Agreement). IF YOU DO NOT AGREE TO THE ML2 LICENSE AGREEMENT, THEN YOU MAY NOT CONTINUE WITH THE DOWNLOAD OR USE OF THE DEVELOPER RESOURCES PUBLISHED ON THIS WEBSITE.

Terms and conditions applicable to third-party materials accompanying this distribution may also be found in the top-level NOTICE file appearing herein.

Please note that this preview of Magic Leap Remote Rendering is provided for use  with Nvidia Holoscan running on IGX Orion devkit, and is not fully tested for other use cases
This preview build is based upon Magic Leap Remote Rendering build 1.2.88, and is intended to be used with Magic Leap OS release 1.3.0-dev2

Open Source Software Notices for this software can be found at https://www.magicleap.com/ml2-open-source-software-notices